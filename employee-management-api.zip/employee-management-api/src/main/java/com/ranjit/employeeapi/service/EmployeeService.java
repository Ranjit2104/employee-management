package com.ranjit.employeeapi.service;

import com.ranjit.employeeapi.dto.EmployeeDTO;
import com.ranjit.employeeapi.entity.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

public interface EmployeeService {
    EmployeeDTO.Response createEmployee(EmployeeDTO.Request request);
    EmployeeDTO.Response getEmployeeById(Long id);
    EmployeeDTO.Response getEmployeeByEmail(String email);
    Page<EmployeeDTO.Response> getAllEmployees(Pageable pageable);
    Page<EmployeeDTO.Response> searchEmployees(String keyword, Pageable pageable);
    EmployeeDTO.Response updateEmployee(Long id, EmployeeDTO.Request request);
    void deleteEmployee(Long id);
    List<EmployeeDTO.Response> getEmployeesByDepartment(String department);
    List<EmployeeDTO.Response> getEmployeesByStatus(Employee.EmployeeStatus status);
    Map<String, Object> getEmployeeStats();
}
