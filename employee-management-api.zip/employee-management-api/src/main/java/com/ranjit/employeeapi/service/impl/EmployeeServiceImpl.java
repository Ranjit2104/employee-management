package com.ranjit.employeeapi.service.impl;

import com.ranjit.employeeapi.dto.EmployeeDTO;
import com.ranjit.employeeapi.entity.Employee;
import com.ranjit.employeeapi.exception.DuplicateResourceException;
import com.ranjit.employeeapi.exception.ResourceNotFoundException;
import com.ranjit.employeeapi.repository.EmployeeRepository;
import com.ranjit.employeeapi.service.EmployeeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;

    @Override
    public EmployeeDTO.Response createEmployee(EmployeeDTO.Request request) {
        log.info("Creating employee with email: {}", request.getEmail());

        if (employeeRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Employee already exists with email: " + request.getEmail());
        }

        Employee employee = Employee.builder()
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .email(request.getEmail())
                .department(request.getDepartment())
                .designation(request.getDesignation())
                .salary(request.getSalary())
                .status(request.getStatus() != null ? request.getStatus() : Employee.EmployeeStatus.ACTIVE)
                .build();

        Employee saved = employeeRepository.save(employee);
        log.info("Employee created successfully with id: {}", saved.getId());
        return mapToResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public EmployeeDTO.Response getEmployeeById(Long id) {
        Employee employee = findEmployeeById(id);
        return mapToResponse(employee);
    }

    @Override
    @Transactional(readOnly = true)
    public EmployeeDTO.Response getEmployeeByEmail(String email) {
        Employee employee = employeeRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with email: " + email));
        return mapToResponse(employee);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<EmployeeDTO.Response> getAllEmployees(Pageable pageable) {
        return employeeRepository.findAll(pageable).map(this::mapToResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<EmployeeDTO.Response> searchEmployees(String keyword, Pageable pageable) {
        return employeeRepository.searchEmployees(keyword, pageable).map(this::mapToResponse);
    }

    @Override
    public EmployeeDTO.Response updateEmployee(Long id, EmployeeDTO.Request request) {
        log.info("Updating employee with id: {}", id);
        Employee employee = findEmployeeById(id);

        // Check email uniqueness only if email is being changed
        if (!employee.getEmail().equals(request.getEmail()) &&
                employeeRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email already in use: " + request.getEmail());
        }

        employee.setFirstName(request.getFirstName());
        employee.setLastName(request.getLastName());
        employee.setEmail(request.getEmail());
        employee.setDepartment(request.getDepartment());
        employee.setDesignation(request.getDesignation());
        employee.setSalary(request.getSalary());
        if (request.getStatus() != null) {
            employee.setStatus(request.getStatus());
        }

        Employee updated = employeeRepository.save(employee);
        log.info("Employee updated successfully: {}", id);
        return mapToResponse(updated);
    }

    @Override
    public void deleteEmployee(Long id) {
        log.info("Deleting employee with id: {}", id);
        Employee employee = findEmployeeById(id);
        employeeRepository.delete(employee);
        log.info("Employee deleted successfully: {}", id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EmployeeDTO.Response> getEmployeesByDepartment(String department) {
        return employeeRepository.findByDepartment(department)
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<EmployeeDTO.Response> getEmployeesByStatus(Employee.EmployeeStatus status) {
        return employeeRepository.findByStatus(status)
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Object> getEmployeeStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalEmployees", employeeRepository.count());
        stats.put("activeEmployees", employeeRepository.countByStatus(Employee.EmployeeStatus.ACTIVE));
        stats.put("inactiveEmployees", employeeRepository.countByStatus(Employee.EmployeeStatus.INACTIVE));
        stats.put("onLeave", employeeRepository.countByStatus(Employee.EmployeeStatus.ON_LEAVE));
        stats.put("departments", employeeRepository.findAllDepartments());
        return stats;
    }

    private Employee findEmployeeById(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));
    }

    private EmployeeDTO.Response mapToResponse(Employee employee) {
        return EmployeeDTO.Response.builder()
                .id(employee.getId())
                .firstName(employee.getFirstName())
                .lastName(employee.getLastName())
                .email(employee.getEmail())
                .department(employee.getDepartment())
                .designation(employee.getDesignation())
                .salary(employee.getSalary())
                .status(employee.getStatus())
                .createdAt(employee.getCreatedAt())
                .updatedAt(employee.getUpdatedAt())
                .build();
    }
}
