package com.ranjit.employeeapi.dto;

import com.ranjit.employeeapi.entity.Employee;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class EmployeeDTO {

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Request {

        @NotBlank(message = "First name is required")
        private String firstName;

        @NotBlank(message = "Last name is required")
        private String lastName;

        @Email(message = "Invalid email format")
        @NotBlank(message = "Email is required")
        private String email;

        @NotBlank(message = "Department is required")
        private String department;

        @NotBlank(message = "Designation is required")
        private String designation;

        @NotNull(message = "Salary is required")
        @Positive(message = "Salary must be positive")
        private BigDecimal salary;

        private Employee.EmployeeStatus status;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Response {
        private Long id;
        private String firstName;
        private String lastName;
        private String email;
        private String department;
        private String designation;
        private BigDecimal salary;
        private Employee.EmployeeStatus status;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }
}
