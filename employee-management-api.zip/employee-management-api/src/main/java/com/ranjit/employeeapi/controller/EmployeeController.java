package com.ranjit.employeeapi.controller;

import com.ranjit.employeeapi.dto.ApiResponse;
import com.ranjit.employeeapi.dto.EmployeeDTO;
import com.ranjit.employeeapi.entity.Employee;
import com.ranjit.employeeapi.service.EmployeeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/employees")
@RequiredArgsConstructor
@Tag(name = "Employee Management", description = "APIs for managing employees")
@CrossOrigin(origins = "*")
public class EmployeeController {

    private final EmployeeService employeeService;

    @PostMapping
    @Operation(summary = "Create a new employee")
    public ResponseEntity<ApiResponse<EmployeeDTO.Response>> createEmployee(
            @Valid @RequestBody EmployeeDTO.Request request) {
        EmployeeDTO.Response response = employeeService.createEmployee(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Employee created successfully", response));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get employee by ID")
    public ResponseEntity<ApiResponse<EmployeeDTO.Response>> getEmployeeById(@PathVariable Long id) {
        EmployeeDTO.Response response = employeeService.getEmployeeById(id);
        return ResponseEntity.ok(ApiResponse.success("Employee fetched successfully", response));
    }

    @GetMapping("/email/{email}")
    @Operation(summary = "Get employee by email")
    public ResponseEntity<ApiResponse<EmployeeDTO.Response>> getEmployeeByEmail(@PathVariable String email) {
        EmployeeDTO.Response response = employeeService.getEmployeeByEmail(email);
        return ResponseEntity.ok(ApiResponse.success("Employee fetched successfully", response));
    }

    @GetMapping
    @Operation(summary = "Get all employees with pagination and sorting")
    public ResponseEntity<ApiResponse<Page<EmployeeDTO.Response>>> getAllEmployees(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {

        Sort sort = sortDir.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<EmployeeDTO.Response> employees = employeeService.getAllEmployees(pageable);
        return ResponseEntity.ok(ApiResponse.success("Employees fetched successfully", employees));
    }

    @GetMapping("/search")
    @Operation(summary = "Search employees by keyword")
    public ResponseEntity<ApiResponse<Page<EmployeeDTO.Response>>> searchEmployees(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<EmployeeDTO.Response> employees = employeeService.searchEmployees(keyword, pageable);
        return ResponseEntity.ok(ApiResponse.success("Search results", employees));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an employee")
    public ResponseEntity<ApiResponse<EmployeeDTO.Response>> updateEmployee(
            @PathVariable Long id,
            @Valid @RequestBody EmployeeDTO.Request request) {
        EmployeeDTO.Response response = employeeService.updateEmployee(id, request);
        return ResponseEntity.ok(ApiResponse.success("Employee updated successfully", response));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete an employee")
    public ResponseEntity<ApiResponse<Void>> deleteEmployee(@PathVariable Long id) {
        employeeService.deleteEmployee(id);
        return ResponseEntity.ok(ApiResponse.success("Employee deleted successfully", null));
    }

    @GetMapping("/department/{department}")
    @Operation(summary = "Get employees by department")
    public ResponseEntity<ApiResponse<List<EmployeeDTO.Response>>> getByDepartment(
            @PathVariable String department) {
        List<EmployeeDTO.Response> employees = employeeService.getEmployeesByDepartment(department);
        return ResponseEntity.ok(ApiResponse.success("Employees fetched by department", employees));
    }

    @GetMapping("/status/{status}")
    @Operation(summary = "Get employees by status")
    public ResponseEntity<ApiResponse<List<EmployeeDTO.Response>>> getByStatus(
            @PathVariable Employee.EmployeeStatus status) {
        List<EmployeeDTO.Response> employees = employeeService.getEmployeesByStatus(status);
        return ResponseEntity.ok(ApiResponse.success("Employees fetched by status", employees));
    }

    @GetMapping("/stats")
    @Operation(summary = "Get employee statistics")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getStats() {
        Map<String, Object> stats = employeeService.getEmployeeStats();
        return ResponseEntity.ok(ApiResponse.success("Employee stats fetched", stats));
    }
}
