package com.ranjit.employeeapi.config;

import com.ranjit.employeeapi.entity.Employee;
import com.ranjit.employeeapi.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final EmployeeRepository employeeRepository;

    @Override
    public void run(String... args) {
        if (employeeRepository.count() == 0) {
            log.info("Initializing demo data...");

            List<Employee> employees = List.of(
                Employee.builder().firstName("Ranjit").lastName("Kumar")
                    .email("ranjit.kumar@company.com").department("Engineering")
                    .designation("Senior Java Developer").salary(new BigDecimal("85000"))
                    .status(Employee.EmployeeStatus.ACTIVE).build(),

                Employee.builder().firstName("Priya").lastName("Sharma")
                    .email("priya.sharma@company.com").department("Engineering")
                    .designation("Java Developer").salary(new BigDecimal("65000"))
                    .status(Employee.EmployeeStatus.ACTIVE).build(),

                Employee.builder().firstName("Amit").lastName("Singh")
                    .email("amit.singh@company.com").department("DevOps")
                    .designation("DevOps Engineer").salary(new BigDecimal("75000"))
                    .status(Employee.EmployeeStatus.ACTIVE).build(),

                Employee.builder().firstName("Sneha").lastName("Patel")
                    .email("sneha.patel@company.com").department("QA")
                    .designation("QA Lead").salary(new BigDecimal("60000"))
                    .status(Employee.EmployeeStatus.ACTIVE).build(),

                Employee.builder().firstName("Vikram").lastName("Reddy")
                    .email("vikram.reddy@company.com").department("Engineering")
                    .designation("Tech Lead").salary(new BigDecimal("95000"))
                    .status(Employee.EmployeeStatus.ON_LEAVE).build()
            );

            employeeRepository.saveAll(employees);
            log.info("Demo data initialized with {} employees", employees.size());
        }
    }
}
