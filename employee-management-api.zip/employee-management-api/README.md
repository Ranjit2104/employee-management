# 👨‍💼 Employee Management REST API

A **production-ready RESTful API** for Employee Management built with **Spring Boot 3**, **Spring Data JPA**, and **H2/MySQL**. This project demonstrates clean architecture, best practices, and enterprise-level patterns.

[![Java](https://img.shields.io/badge/Java-17-orange)](https://www.oracle.com/java/)
[![Spring Boot](https://img.shields.io/badge/Spring%20Boot-3.2.0-brightgreen)](https://spring.io/projects/spring-boot)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

---

## 🚀 Features

- ✅ Full **CRUD operations** for Employee management
- ✅ **Pagination & Sorting** on all list endpoints
- ✅ **Search functionality** across multiple fields
- ✅ **Input validation** with detailed error messages
- ✅ **Global exception handling** with meaningful responses
- ✅ **Swagger UI** for interactive API documentation
- ✅ **DTO pattern** for clean API contracts
- ✅ **H2 in-memory DB** for easy local setup (MySQL-ready for production)
- ✅ **Actuator** endpoints for health monitoring
- ✅ **Demo data** auto-loaded on startup

---

## 🛠️ Tech Stack

| Technology | Version |
|---|---|
| Java | 17 |
| Spring Boot | 3.2.0 |
| Spring Data JPA | 3.2.0 |
| H2 Database | Latest |
| MySQL | 8.x (production) |
| Lombok | Latest |
| SpringDoc OpenAPI | 2.3.0 |
| Maven | 3.8+ |

---

## 📁 Project Structure

```
src/main/java/com/ranjit/employeeapi/
├── EmployeeManagementApiApplication.java
├── config/
│   └── DataInitializer.java
├── controller/
│   └── EmployeeController.java
├── dto/
│   ├── ApiResponse.java
│   └── EmployeeDTO.java
├── entity/
│   └── Employee.java
├── exception/
│   ├── DuplicateResourceException.java
│   ├── GlobalExceptionHandler.java
│   └── ResourceNotFoundException.java
├── repository/
│   └── EmployeeRepository.java
└── service/
    ├── EmployeeService.java
    └── impl/
        └── EmployeeServiceImpl.java
```

---

## ⚡ Quick Start

### Prerequisites
- Java 17+
- Maven 3.8+

### Run Locally
```bash
# Clone the repository
git clone https://github.com/ranjit-kumar/employee-management-api.git

# Navigate to project
cd employee-management-api

# Run the application
mvn spring-boot:run
```

The app starts on **http://localhost:8080**

---

## 📖 API Documentation

Once running, access **Swagger UI** at:
```
http://localhost:8080/swagger-ui.html
```

### 📋 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/v1/employees` | Create a new employee |
| `GET` | `/api/v1/employees` | Get all employees (paginated) |
| `GET` | `/api/v1/employees/{id}` | Get employee by ID |
| `GET` | `/api/v1/employees/email/{email}` | Get employee by email |
| `GET` | `/api/v1/employees/search?keyword=` | Search employees |
| `GET` | `/api/v1/employees/department/{dept}` | Get by department |
| `GET` | `/api/v1/employees/status/{status}` | Get by status |
| `GET` | `/api/v1/employees/stats` | Get employee statistics |
| `PUT` | `/api/v1/employees/{id}` | Update employee |
| `DELETE` | `/api/v1/employees/{id}` | Delete employee |

---

## 📝 Sample API Requests

### Create Employee
```json
POST /api/v1/employees
{
  "firstName": "Ranjit",
  "lastName": "Kumar",
  "email": "ranjit@example.com",
  "department": "Engineering",
  "designation": "Senior Java Developer",
  "salary": 85000,
  "status": "ACTIVE"
}
```

### Sample Response
```json
{
  "success": true,
  "message": "Employee created successfully",
  "data": {
    "id": 1,
    "firstName": "Ranjit",
    "lastName": "Kumar",
    "email": "ranjit@example.com",
    "department": "Engineering",
    "designation": "Senior Java Developer",
    "salary": 85000,
    "status": "ACTIVE",
    "createdAt": "2024-01-15T10:30:00"
  },
  "timestamp": "2024-01-15T10:30:00"
}
```

### Get All Employees (with pagination)
```
GET /api/v1/employees?page=0&size=10&sortBy=firstName&sortDir=asc
```

---

## 🗄️ H2 Console
Access the in-memory database UI at:
```
http://localhost:8080/h2-console
JDBC URL: jdbc:h2:mem:employeedb
Username: sa
Password: (empty)
```

---

## 🔧 Switch to MySQL (Production)
In `application.properties`, comment H2 config and uncomment MySQL config:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/employeedb
spring.datasource.username=root
spring.datasource.password=yourpassword
spring.jpa.database-platform=org.hibernate.dialect.MySQLDialect
spring.jpa.hibernate.ddl-auto=update
```

---

## 📊 Health Check
```
GET http://localhost:8080/actuator/health
```

---

## 👤 Author

**Ranjit Kumar**
- LinkedIn: [linkedin.com/in/ranjit-kumar-200852341](https://linkedin.com/in/ranjit-kumar-200852341)
- GitHub: [@ranjit-kumar](https://github.com/ranjit-kumar)

---

## 📄 License
This project is licensed under the MIT License.
